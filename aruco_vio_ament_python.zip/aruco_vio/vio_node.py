def main():
    print('✅ ArUco VIO node running with ament_python setup.')
