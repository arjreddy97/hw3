1. Download KITTI dataset
2. Implement:
   - ORB detection
   - Feature matching
   - Essential matrix
   - Triangulation
   - EKF or simple pose chain
3. Visualize 3D camera trajectory
