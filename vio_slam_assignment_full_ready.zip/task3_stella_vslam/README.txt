1. git clone https://github.com/stella-cv/stella_vslam.git
2. docker build -f Dockerfile.desktop -t stella .
3. Place video in ./data, and create your mycam.yaml
4. docker run -it -v $(pwd)/data:/data stella
5. Inside Docker:
   ./run_equirectangular_video_slam -v ORBvoc.txt -c example/aist/mycam.yaml -m /data/video.mp4
