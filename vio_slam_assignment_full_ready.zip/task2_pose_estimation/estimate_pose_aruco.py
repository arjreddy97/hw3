import cv2
import cv2.aruco as aruco
import numpy as np

aruco_dict = aruco.Dictionary_get(aruco.DICT_4X4_50)
parameters = aruco.DetectorParameters_create()
camera_data = np.load('camera_calib_data.npz')
camera_matrix = camera_data['camera_matrix']
dist_coeffs = camera_data['dist_coeff']

cap = cv2.VideoCapture(0)
marker_length = 0.05

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    corners, ids, _ = aruco.detectMarkers(frame, aruco_dict, parameters=parameters)
    if len(corners) > 0:
        rvecs, tvecs, _ = aruco.estimatePoseSingleMarkers(corners, marker_length, camera_matrix, dist_coeffs)
        for i in range(len(ids)):
            aruco.drawAxis(frame, camera_matrix, dist_coeffs, rvecs[i], tvecs[i], 0.03)
            cv2.putText(frame, f"ID {ids[i][0]}", tuple(corners[i][0][0].astype(int)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)
    cv2.imshow("Pose Estimation", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cap.release()
cv2.destroyAllWindows()
