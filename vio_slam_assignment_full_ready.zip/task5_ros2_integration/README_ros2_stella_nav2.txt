# Task 5: Integrate StellaVSLAM with ROS 2 + Turtlebot Maze

## Step 1: Clone StellaVSLAM ROS2 wrapper

git clone https://github.com/stella-cv/stella_vslam_ros.git
cd stella_vslam_ros

## Step 2: Install dependencies

sudo apt install ros-${ROS_DISTRO}-image-transport ros-${ROS_DISTRO}-cv-bridge

## Step 3: Build in your ROS 2 workspace

cd ~/ros2_ws/src
git clone https://github.com/stella-cv/stella_vslam_ros.git
cd ..
colcon build --packages-select stella_vslam_ros
source install/setup.bash

## Step 4: Use example launch for monocular camera

ros2 launch stella_vslam_ros stella_vslam.launch.py config_file:=/path/to/mycam.yaml vocab_file:=/path/to/ORBvoc.txt

## Step 5: Integrate with Turtlebot Nav2 stack

- Launch turtlebot with camera node publishing to /image_raw
- Launch stella_vslam_ros to subscribe and localize
- Bridge odometry and map frames

🧭 You can then visualize the robot trajectory in RViz and test Nav2 goals.
