import cv2

cap = cv2.VideoCapture(0)
i = 0
while True:
    ret, frame = cap.read()
    if not ret:
        break
    cv2.imshow("Checkerboard View", frame)
    key = cv2.waitKey(1)
    if key == ord('s'):
        cv2.imwrite(f"calib_img_{i}.png", frame)
        print(f"Saved calib_img_{i}.png")
        i += 1
    elif key == 27:
        break
cap.release()
cv2.destroyAllWindows()
