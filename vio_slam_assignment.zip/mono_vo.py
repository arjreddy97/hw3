import cv2
import numpy as np

# Replace with your calibration matrix
K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])

cap = cv2.VideoCapture("my_video.mp4")
ret, prev_frame = cap.read()
prev_gray = cv2.cvtColor(prev_frame, cv2.COLOR_BGR2GRAY)
p0 = cv2.goodFeaturesToTrack(prev_gray, maxCorners=200, qualityLevel=0.3, minDistance=7)

trajectory = [np.eye(4)]

while True:
    ret, frame = cap.read()
    if not ret:
        break
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    p1, st, err = cv2.calcOpticalFlowPyrLK(prev_gray, gray, p0, None)
    if p1 is not None:
        good_new = p1[st==1]
        good_old = p0[st==1]
        E, mask = cv2.findEssentialMat(good_new, good_old, K)
        _, R, t, mask_pose = cv2.recoverPose(E, good_new, good_old, K)
        T = np.eye(4)
        T[:3, :3] = R
        T[:3, 3] = t.flatten()
        trajectory.append(trajectory[-1] @ T)
    prev_gray = gray.copy()
    p0 = good_new.reshape(-1, 1, 2)

cap.release()
