# VIO & SLAM Assignment

## Included Scripts

- `capture_checkerboard.py`: Capture checkerboard images for calibration.
- `calibrate_camera.py`: Perform camera calibration with OpenCV.
- `aruco_pose_estimation.py`: Estimate pose of ArUco markers using calibrated camera.
- `mono_vo.py`: Basic visual odometry pipeline using optical flow and essential matrix.
