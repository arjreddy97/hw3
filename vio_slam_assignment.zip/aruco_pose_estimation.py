import cv2
import cv2.aruco as aruco
import numpy as np

# Replace with calibration results
K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1]])
dist = np.array([k1, k2, p1, p2, k3])

cap = cv2.VideoCapture(0)
marker_length = 0.1

while True:
    ret, frame = cap.read()
    if not ret:
        break
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    corners, ids, _ = aruco.detectMarkers(gray, aruco.getPredefinedDictionary(aruco.DICT_4X4_50))
    if len(corners) > 0:
        rvecs, tvecs, _ = aruco.estimatePoseSingleMarkers(corners, marker_length, K, dist)
        for rvec, tvec in zip(rvecs, tvecs):
            aruco.drawAxis(frame, K, dist, rvec, tvec, 0.05)
            print("tvec:", tvec, "rvec:", rvec)
    cv2.imshow("Frame", frame)
    if cv2.waitKey(1) == 27:
        break
cap.release()
cv2.destroyAllWindows()
