Instructions for running StellaVSLAM using Docker
