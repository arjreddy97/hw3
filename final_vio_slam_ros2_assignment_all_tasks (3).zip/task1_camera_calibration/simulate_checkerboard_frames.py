# Task 1: simulate_checkerboard_frames.py
