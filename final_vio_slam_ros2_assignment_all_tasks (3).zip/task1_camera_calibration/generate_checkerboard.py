# Task 1: generate_checkerboard.py
