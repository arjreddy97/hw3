# Task 1: calibrate_camera.py
