# Task 2: estimate_pose_aruco.py
