Run this inside StellaVSLAM Docker:

./run_equirectangular_video_slam \
  -v ORBvoc.txt \
  -c example/aist/mycam.yaml \
  -m /data/sample_video.mp4
