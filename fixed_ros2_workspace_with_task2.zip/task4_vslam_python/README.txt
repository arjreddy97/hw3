1. Download KITTI dataset (grayscale images)
2. Use OpenCV (ORB+Essential Matrix) or FilterPy (EKF) to estimate motion
3. Plot 2D/3D trajectory
