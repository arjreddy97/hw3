import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import cv2.aruco as aruco
import numpy as np

# === Replace these calibration parameters with yours ===
K = np.array([[620.5, 0, 320.1],
              [0, 619.8, 240.3],
              [0, 0, 1]])
dist = np.array([-0.3, 0.1, 0.0, 0.0, 0.0])  # distortion coefficients

class ArucoPoseEstimator(Node):
    def __init__(self):
        super().__init__('aruco_pose_estimator')
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image, '/camera/image_raw', self.image_callback, 10)
        self.marker_length = 0.1  # marker side length in meters

    def image_callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            dictionary = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
            corners, ids, _ = aruco.detectMarkers(gray, dictionary)

            if ids is not None:
                rvecs, tvecs, _ = aruco.estimatePoseSingleMarkers(
                    corners, self.marker_length, K, dist)
                for rvec, tvec in zip(rvecs, tvecs):
                    aruco.drawAxis(frame, K, dist, rvec, tvec, 0.05)
                    print(f"Detected Marker - tvec: {tvec.flatten()}, rvec: {rvec.flatten()}")

            aruco.drawDetectedMarkers(frame, corners, ids)
            cv2.imshow("Aruco Marker Pose Estimation", frame)
            cv2.waitKey(1)

        except Exception as e:
            self.get_logger().error(f"Error processing image: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = ArucoPoseEstimator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
