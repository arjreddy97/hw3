from setuptools import setup

package_name = 'turtlebot_vio'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name, 'task2_pose_estimation'],
    data_files=[
        ('share/' + package_name + '/launch', ['launch/aruco_pose.launch.py']),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='your@email.com',
    description='Turtlebot VIO and ArUco-based pose estimation',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'estimate_pose_aruco = task2_pose_estimation.estimate_pose_aruco:main',
        ],
    },
)
