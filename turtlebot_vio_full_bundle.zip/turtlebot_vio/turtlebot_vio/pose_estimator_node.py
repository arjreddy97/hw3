#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import PoseStamped
import cv2
from cv_bridge import CvBridge
import numpy as np
import math

ARUCO_DICT = cv2.aruco.Dictionary_get(cv2.aruco.DICT_4X4_50)
ARUCO_PARAMS = cv2.aruco.DetectorParameters_create()

class MultiObjectPoseEstimator(Node):
    def __init__(self):
        super().__init__('multi_object_pose_estimator')

        self.declare_parameter('calibration_file', 'camera_calib_data.npz')
        self.declare_parameter('aruco_marker_length', 0.05)
        self.declare_parameter('output_frame_id', 'world')

        calib_file = self.get_parameter('calibration_file').get_parameter_value().string_value
        try:
            data = np.load(calib_file)
            self.camera_matrix = data['camera_matrix']
            self.dist_coeffs = data['dist_coeff']
        except Exception as e:
            self.get_logger().error(f"Failed to load calibration: {e}")
            self.camera_matrix = None
            self.dist_coeffs = None

        self.marker_length = self.get_parameter('aruco_marker_length').get_parameter_value().double_value
        self.output_frame = self.get_parameter('output_frame_id').get_parameter_value().string_value

        self.bridge = CvBridge()
        self.image_sub = self.create_subscription(Image, '/camera/image_raw', self.image_callback, 10)
        self.pose_pub = self.create_publisher(PoseStamped, '/camera_pose', 10)

    def image_callback(self, msg):
        if self.camera_matrix is None:
            return

        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        corners, ids, _ = cv2.aruco.detectMarkers(gray, ARUCO_DICT, parameters=ARUCO_PARAMS)
        if ids is not None:
            rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(
                corners, self.marker_length, self.camera_matrix, self.dist_coeffs)

            for i in range(len(ids)):
                rvec, tvec = rvecs[i][0], tvecs[i][0]
                marker_id = int(ids[i])

                R, _ = cv2.Rodrigues(rvec)
                R_inv = R.T
                cam_position = -R_inv @ tvec

                qw = math.sqrt(1.0 + R_inv[0,0] + R_inv[1,1] + R_inv[2,2]) / 2.0
                qx = (R_inv[2,1] - R_inv[1,2]) / (4.0 * qw)
                qy = (R_inv[0,2] - R_inv[2,0]) / (4.0 * qw)
                qz = (R_inv[1,0] - R_inv[0,1]) / (4.0 * qw)

                pose_msg = PoseStamped()
                pose_msg.header.stamp = self.get_clock().now().to_msg()
                pose_msg.header.frame_id = self.output_frame
                pose_msg.pose.position.x = float(cam_position[0])
                pose_msg.pose.position.y = float(cam_position[1])
                pose_msg.pose.position.z = float(cam_position[2])
                pose_msg.pose.orientation.x = float(qx)
                pose_msg.pose.orientation.y = float(qy)
                pose_msg.pose.orientation.z = float(qz)
                pose_msg.pose.orientation.w = float(qw)

                self.pose_pub.publish(pose_msg)
                self.get_logger().info(f"Published pose for ArUco marker ID {marker_id}")

def main(args=None):
    rclpy.init(args=args)
    node = MultiObjectPoseEstimator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
