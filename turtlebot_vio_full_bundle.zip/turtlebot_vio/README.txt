Usage Instructions:

1. Generate ArUco markers:
   python3 scripts/generate_aruco_markers.py

2. Capture checkerboard images as frame_0.png, frame_1.png...
   Then run calibration:
   python3 scripts/calibrate_camera.py

3. Build the package:
   colcon build --packages-select turtlebot_vio
   source install/setup.bash

4. Launch:
   ros2 launch turtlebot_vio vio_aruco.launch.py

Ensure your camera publishes to /camera/image_raw and markers are visible.
