# Task 5: StellaVSLAM Integration with ROS 2 + Nav2

1. Clone StellaVSLAM ROS 2 wrapper:
   https://github.com/stella-cv/stella_vslam_ros

2. Build using colcon in your ROS 2 workspace:
   cd ~/ros2_ws/src
   git clone https://github.com/stella-cv/stella_vslam_ros.git
   cd ..
   colcon build

3. Include your calibration in a YAML (like mycam.yaml) and point to it in your launch file.

4. Launch the system:
   ros2 launch stella_vslam_ros run_stereo.launch.py

5. Integrate with Nav2 stack:
   - Publish pose from StellaVSLAM to `/amcl_pose` or `/tf`
   - Use `robot_localization` or EKF to fuse VIO + odometry
   - Enable global planner in Nav2

6. Run:
   ros2 launch nav2_bringup bringup_launch.py

7. Verify localization and mapping in RViz

