1. Download KITTI dataset (odometry + grayscale images)
2. Use Python (OpenCV or FilterPy) to:
   - Detect ORB features
   - Match across frames
   - Estimate essential matrix
   - Recover pose
   - Visualize trajectory
