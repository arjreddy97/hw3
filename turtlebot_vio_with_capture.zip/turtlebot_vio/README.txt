Usage Instructions:

1. Generate ArUco markers:
   sudo python3 scripts/generate_aruco_markers.py

2. Generate checkerboard:
   sudo python3 scripts/generate_checkerboard.py
   Display/print checkerboard.png

3. Capture camera frames while pointing at checkerboard:
   sudo python3 scripts/capture_frames.py
   Press 'c' to capture, 'q' to quit

4. Calibrate camera:
   sudo python3 scripts/calibrate_camera.py

5. Build the ROS 2 package:
   colcon build --packages-select turtlebot_vio
   source install/setup.bash

6. Launch VIO:
   ros2 launch turtlebot_vio vio_aruco.launch.py
