1. Clone: https://github.com/stella-cv/stella_vslam.git
2. Build Docker image:
   docker build -f Dockerfile.desktop -t stella .
3. Run SLAM:
   docker run -it -v $(pwd)/data:/data stella
4. Inside container:
   ./run_equirectangular_video_slam -v ORBvoc.txt -c example/aist/mycam.yaml -m /data/your_video.mp4
