Use KITTI dataset. Process grayscale images using ORB features, match keypoints, estimate pose and plot trajectory.
Use cv2.findEssentialMat + cv2.recoverPose or PnP + EKF/FilterPy for better results.
