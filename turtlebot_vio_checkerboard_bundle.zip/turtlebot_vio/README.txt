Usage Instructions:

1. Generate ArUco markers:
   python3 scripts/generate_aruco_markers.py

2. Generate a checkerboard image (6x9 grid):
   python3 scripts/generate_checkerboard.py
   Then display or print the checkerboard.

3. Capture images showing checkerboard as frame_0.png, etc.
   Then calibrate:
   python3 scripts/calibrate_camera.py

4. Build the ROS 2 package:
   colcon build --packages-select turtlebot_vio
   source install/setup.bash

5. Launch pose estimator:
   ros2 launch turtlebot_vio vio_aruco.launch.py

Ensure your robot publishes /camera/image_raw and sees the ArUco markers.
