from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtlebot_vio',
            executable='estimate_pose_aruco',
            name='aruco_pose_node',
            output='screen'
        )
    ])
