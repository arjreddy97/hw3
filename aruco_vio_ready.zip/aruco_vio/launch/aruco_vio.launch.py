from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='aruco_vio',
            executable='vio_node',
            name='vio_node',
            output='screen',
        )
    ])
