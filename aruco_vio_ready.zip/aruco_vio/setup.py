from setuptools import setup

package_name = 'aruco_vio'

setup(
    name=package_name,
    version='0.1.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/aruco_vio.launch.py']),
    ],
    install_requires=['setuptools'],
    include_package_data=True,
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='you@example.com',
    description='Simple test package for ROS2 Python launch',
    license='MIT',
    entry_points={
        'console_scripts': [
            'vio_node = aruco_vio.vio_node:main'
        ],
    },
)
