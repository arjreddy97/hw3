Integrate StellaVSLAM into ROS2:
- Launch StellaVSLAM as a ROS2 node
- Use nav2 stack
- Demonstrate global localization in the maze