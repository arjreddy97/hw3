Instructions:
1. Clone StellaVSLAM
2. Run Docker container with PangolinViewer
3. Map host directory containing datasets
4. Run example with aist_living_lab_1
5. Repeat with webcam video and your calibration