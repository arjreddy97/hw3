import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np

class PoseEstimator(Node):
    def __init__(self):
        super().__init__('pose_estimator')
        self.bridge = CvBridge()
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.listener_callback,
            10
        )
        calib = np.load('camera_calib_data.npz')
        self.K = calib['camera_matrix']
        self.D = calib['dist_coeff']
        self.aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_5X5_50)
        self.aruco_params = cv2.aruco.DetectorParameters_create()

    def listener_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = cv2.aruco.detectMarkers(gray, self.aruco_dict, parameters=self.aruco_params)
        if ids is not None:
            rvecs, tvecs, _ = cv2.aruco.estimatePoseSingleMarkers(corners, 0.1, self.K, self.D)
            for rvec, tvec, marker_id in zip(rvecs, tvecs, ids.flatten()):
                self.get_logger().info(f"Marker {marker_id} at tvec={tvec.flatten()}, rvec={rvec.flatten()}")