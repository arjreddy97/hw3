
# Task 3: StellaVSLAM Setup

## Docker Build
git clone --recursive https://github.com/stella-cv/stella_vslam.git
cd stella_vslam
docker build -t stella_vslam -f Dockerfile.desktop .

## Run with Video
docker run -it --rm -v $PWD:/data -e DISPLAY=$DISPLAY \
    -v /tmp/.X11-unix:/tmp/.X11-unix \
    stella_vslam ./run_video_slam \
    -v orb_vocab.fbow -c config.yaml -m /data/video.mp4
