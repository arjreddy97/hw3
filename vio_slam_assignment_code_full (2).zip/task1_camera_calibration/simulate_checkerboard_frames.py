import cv2
import numpy as np

img = cv2.imread("checkerboard.png")
for i in range(10):
    M = cv2.getRotationMatrix2D((img.shape[1]//2, img.shape[0]//2), i*5, 1)
    frame = cv2.warpAffine(img, M, (img.shape[1], img.shape[0]))
    cv2.imwrite(f"frame_{i}.png", frame)