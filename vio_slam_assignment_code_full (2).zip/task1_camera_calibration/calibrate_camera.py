import cv2
import numpy as np
import glob

cb_size = (9, 6)
objp = np.zeros((cb_size[0]*cb_size[1], 3), np.float32)
objp[:, :2] = np.mgrid[0:cb_size[0], 0:cb_size[1]].T.reshape(-1, 2)

objpoints, imgpoints = [], []
images = glob.glob('frame_*.png')

for fname in images:
    img = cv2.imread(fname)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    ret, corners = cv2.findChessboardCorners(gray, cb_size, None)
    if ret:
        objpoints.append(objp)
        imgpoints.append(corners)

ret, mtx, dist, _, _ = cv2.calibrateCamera(objpoints, imgpoints, gray.shape[::-1], None, None)
np.savez('camera_calib_data.npz', camera_matrix=mtx, dist_coeff=dist)
print("Calibration saved to camera_calib_data.npz")