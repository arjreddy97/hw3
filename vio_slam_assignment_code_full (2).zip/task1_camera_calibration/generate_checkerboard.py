import cv2
import numpy as np

# Create and save checkerboard image
rows, cols = 6, 9
square_size = 50
img = np.ones((rows*square_size, cols*square_size), dtype=np.uint8) * 255

for i in range(rows):
    for j in range(cols):
        if (i + j) % 2 == 0:
            cv2.rectangle(img, (j*square_size, i*square_size),
                          ((j+1)*square_size, (i+1)*square_size), 0, -1)

cv2.imwrite("checkerboard.png", img)