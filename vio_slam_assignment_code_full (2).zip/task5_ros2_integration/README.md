
# Task 5: Integration

## Summary
- Task 1: Camera calibration with real/simulated checkerboard
- Task 2: ArUco pose estimation in simulation with ROS2
- Task 3: StellaVSLAM mapping using Docker
- Task 4: Custom VSLAM pipeline in Python
- Task 5: This integration + reporting guide
