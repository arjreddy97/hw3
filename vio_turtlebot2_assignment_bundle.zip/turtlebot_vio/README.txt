📦 TurtleBot2 VIO Assignment Bundle (ROS 2 Jazzy)

---

🎯 TASK 1: Camera Calibration (25 points)

1. Generate Checkerboard:
   python3 scripts/generate_checkerboard.py

2. Capture Frames:
   ros2 run turtlebot_vio capture_frames
   ➤ Press 'c' to capture a frame, 'q' to quit

3. Calibrate Camera:
   python3 scripts/calibrate_camera.py
   ➤ Produces: camera_calib_data.npz

---

🧠 TASK 2: VIO Principles (25 points)

1. Check pose_estimator_node.py:
   ➤ Uses solvePnP to estimate pose from ArUco markers

2. Run Node:
   ros2 launch turtlebot_vio vio_aruco.launch.py
   ➤ Subscribes: /camera/image_raw
   ➤ Publishes: /camera_pose

---

🧱 TASK 3: Featurize Maze (10 points)

1. Generate ArUco Markers:
   python3 scripts/generate_aruco_markers.py

2. Place markers (e.g., aruco_marker_0.png) on maze objects

---

🚀 TASK 4: VIO Execution (40 points)

1. Launch Simulation with IMU + Camera

2. Drive TurtleBot2 with teleop:
   ros2 run teleop_twist_keyboard teleop_twist_keyboard cmd_vel:=/cmd_vel

3. Run VIO:
   ros2 launch turtlebot_vio vio_aruco.launch.py

4. View Pose:
   ros2 topic echo /camera_pose

✅ Done!
