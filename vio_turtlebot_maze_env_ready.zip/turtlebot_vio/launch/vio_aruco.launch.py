from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='turtlebot_vio',
            executable='pose_estimator_node',
            name='pose_estimator_node',
            output='screen',
            parameters=[{
                'calibration_file': 'camera_calib_data.npz',
                'aruco_marker_length': 0.05,
                'output_frame_id': 'world'
            }]
        )
    ])
