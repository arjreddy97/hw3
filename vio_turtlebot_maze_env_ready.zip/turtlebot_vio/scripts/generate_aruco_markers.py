import cv2
import cv2.aruco as aruco

aruco_dict = aruco.getPredefinedDictionary(aruco.DICT_4X4_50)
for id in range(10):
    img = aruco.drawMarker(aruco_dict, id, 200)
    cv2.imwrite(f'aruco_marker_{id}.png', img)
print("ArUco markers saved.")
