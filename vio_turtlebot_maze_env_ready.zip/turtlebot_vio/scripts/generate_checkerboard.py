import numpy as np
import cv2

rows, cols = 6, 9
square_size = 50
img_size = (cols * square_size, rows * square_size)
checkerboard = np.zeros((img_size[1], img_size[0]), dtype=np.uint8)

for i in range(rows):
    for j in range(cols):
        if (i + j) % 2:
            x0 = j * square_size
            y0 = i * square_size
            checkerboard[y0:y0 + square_size, x0:x0 + square_size] = 255

cv2.imwrite("checkerboard.png", checkerboard)
print("Saved checkerboard.png")
