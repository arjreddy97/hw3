📦 TurtleBot Maze VIO Assignment (ROS 2 Jazzy + Gazebo)

✅ Works with the turtlebot-maze Gazebo world you are running.

---

🎯 Camera Calibration (25 points)
python3 scripts/generate_checkerboard.py
ros2 launch tb_worlds tb_maze.launch.py
ros2 run turtlebot_vio capture_frames
python3 scripts/calibrate_camera.py

---

🧠 VIO Principles (25 points)
ros2 launch turtlebot_vio vio_aruco.launch.py
ros2 topic echo /camera_pose

---

🧱 Featurization of the Maze (10 points)
python3 scripts/generate_aruco_markers.py
# Paste markers in visible places in the maze

---

🚀 VIO Execution (40 points)
ros2 launch tb_worlds tb_maze.launch.py
ros2 run teleop_twist_keyboard teleop_twist_keyboard cmd_vel:=/cmd_vel
ros2 launch turtlebot_vio vio_aruco.launch.py
ros2 topic echo /camera_pose
