## Task 4: Understand VSLAM

Use KITTI dataset to implement:
- Feature detection (ORB/SIFT)
- Matching
- Essential matrix + triangulation
- Camera pose tracking using Kalman/Extended Filter

Steps:
1. Download KITTI odometry dataset:
   https://www.cvlibs.net/datasets/kitti/eval_odometry.php

2. Use OpenCV or libraries like RVC3-python or FilterPy.

3. Plot the estimated camera path.
