## Task 3: StellaVSLAM Demo

1. Clone:
   git clone https://github.com/stella-cv/stella_vslam.git
   cd stella_vslam

2. Build Docker image:
   docker build -f Dockerfile.desktop -t stella .

3. Download dataset and place your video in ./data

4. Edit a YAML config (copy from example/aist/equirectangular.yaml) using Task 1 calibration.

5. Run in docker:
   docker run --rm -it -v $(pwd)/data:/data stella

Inside the container:
   ./run_equirectangular_video_slam -v ORBvoc.txt -c example/aist/mycam.yaml -m /data/your_video.mp4
