def main():
    print('✅ ArUco VIO node executed successfully.')
