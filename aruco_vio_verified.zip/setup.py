from setuptools import setup, find_packages

setup(
    name='aruco_vio',
    version='0.1.0',
    packages=find_packages(),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/aruco_vio']),
        ('share/aruco_vio', ['package.xml']),
        ('share/aruco_vio/launch', ['launch/aruco_vio.launch.py']),
    ],
    install_requires=['setuptools'],
    include_package_data=True,
    zip_safe=True,
    maintainer='Your Name',
    maintainer_email='you@example.com',
    description='Verified ROS 2 Python package for VIO',
    license='MIT',
    entry_points={
        'console_scripts': [
            'vio_node = aruco_vio.vio_node:main',
        ],
    },
)
