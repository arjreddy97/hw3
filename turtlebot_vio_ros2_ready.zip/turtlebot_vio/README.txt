Instructions:

1. Place turtlebot_vio in your ROS 2 workspace (e.g., ~/ros2_ws/src)
2. Build:
   cd ~/ros2_ws
   colcon build --packages-select turtlebot_vio
   source install/setup.bash

3. Launch the simulation:
   cd ~/turtlebot-maze
   docker compose up demo-world

4. In another terminal:
   docker exec -it turtlebot-maze_demo-world_1 bash
   cd /root/ros2_ws/src/turtlebot_vio/

5. Capture frames for calibration:
   ros2 run turtlebot_vio capture_frames
   Press 'c' to capture, 'q' to quit.

6. Run calibration:
   python3 calibrate_sim_camera.py

7. Spawn cube in simulation if not present:
   ros2 run gazebo_ros spawn_entity.py -entity vio_cube -file /root/cube.sdf -x 2.0 -y 0.0 -z 0.1

8. Run the VIO node:
   ros2 run turtlebot_vio pose_estimator_node

9. (Optional) Visualize:
   ros2 topic echo /camera_pose
   or
   rviz2 → Add Pose → Topic: /camera_pose
